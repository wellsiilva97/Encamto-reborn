import { ShoppingCart } from 'lucide-react';

const products = [
  { name: 'Boneca Reborn Nanda', price: 'R$ 499,90', image: 'https://i.imgur.com/1.jpg' },
  { name: 'Boneca Reborn Mariah', price: 'R$ 529,90', image: 'https://i.imgur.com/2.jpg' },
  { name: 'Boneco Reborn Vitor', price: 'R$ 519,90', image: 'https://i.imgur.com/3.jpg' },
  { name: 'Boneca Reborn Mila', price: 'R$ 559,90', image: 'https://i.imgur.com/4.jpg' },
  { name: 'Boneca Reborn Samira', price: 'R$ 549,90', image: 'https://i.imgur.com/5.jpg' },
  { name: 'Boneca Reborn Stefany', price: 'R$ 599,90', image: 'https://i.imgur.com/6.jpg' }
];

export default function EncantoReborn() {
  return (
    <div style={{ fontFamily: 'Arial', padding: 20, maxWidth: 1200, margin: '0 auto' }}>
      <h1 style={{ fontSize: 36, color: '#d63384', textAlign: 'center' }}>Encanto Reborn</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: 20, marginTop: 30 }}>
        {products.map((p, i) => (
          <div key={i} style={{ border: '1px solid #eee', borderRadius: 10, overflow: 'hidden', boxShadow: '0 0 10px #eee' }}>
            <img src={p.image} alt={p.name} style={{ width: '100%', height: 250, objectFit: 'cover' }} />
            <div style={{ padding: 15 }}>
              <h2 style={{ fontSize: 20, color: '#c2185b' }}>{p.name}</h2>
              <p style={{ fontSize: 16, color: '#555' }}>{p.price}</p>
              <button style={{ marginTop: 10, width: '100%', background: '#d63384', color: 'white', padding: '10px', border: 'none', borderRadius: 5 }}>
                <ShoppingCart size={16} style={{ marginRight: 6 }} /> Comprar
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}